#include <stdio.h>
#include <stdlib.h>

int main()
{
    int idade;

    printf("Digite a sua idade: ");
    scanf("%d", &idade);

    if(idade < 18){
        printf("JOVEM\n");
    }

    if(idade >= 18 && idade < 60){
        printf("ADULTO\n");
    }
    else{
        if(idade >= 60){
            printf("IDOSO\n");
        }
    }

    return 0;
}
