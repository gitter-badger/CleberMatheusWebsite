#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a;

    printf("Digite um numero: ");
    scanf("%d",&a);

    if(a==0){
        printf("ZERO\n");
    }
    else{
        if(a==1){
            printf("UM\n");
        }
        else if(a==2){
            printf("DOIS\n");
        }
        else if(a==3){
            printf("TRES\n");
        }
        else if(a==4){
            printf("QUATRO\n");
        }
        else if(a==5){
            printf("CINCO\n");
        }
        else if(a==6){
            printf("SEIS\n");
        }
        else if(a==7){
            printf("SETE\n");
        }
        else if(a==8){
            printf("OITO\n");
        }
        else if(a==9){
            printf("NOVE\n");
        }
        else{
            printf("ENTRADA INVALIDA!\n");
        }
    }

    return 0;
}
