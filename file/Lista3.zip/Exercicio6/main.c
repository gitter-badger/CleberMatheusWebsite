#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b;
    float q;

    printf("Digite dois numeros separados: ");
    scanf("%d %d",&a,&b);
    q = (float)a/b;

    printf("Quociente: %f\n",q);

    return 0;
}
