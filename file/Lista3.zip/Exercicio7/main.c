#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b;
    float r;

    printf("Digite dois numeros: ");
    scanf("%d %d",&a,&b);

    r = ( (float) a*100)/b;

    printf("Resultado: %f%%\n",r);

    return 0;
}
