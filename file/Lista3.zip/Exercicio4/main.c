#include <stdio.h>
#include <stdlib.h>

int main()
{
    int opcao,a,b;

    printf("Escolha uma das quatros opcoes abaixo: \n");
    printf("1 - Soma\n2 - Diferenca\n3 - Multiplicacao\n4 - Quociente e Resto\n");

    printf("Agora digite a opcao escolhida: ");
    scanf("%d", &opcao);

    printf("Agora digite dois numeros separados: ");
    scanf("%d %d", &a,&b);

    switch(opcao){
    case 1:
        printf("Soma: %d\n", a+b);
        break;
    case 2:
        printf("Diferenca: %d\n",a-b);
        break;
    case 3:
        printf("Multiplicacao: %d\n", a*b);
        break;
    case 4:
        printf("Quociente: %d\n", a/b);
        printf("Resto: %d\n", a%b);
        break;
    default:
        printf("OPCAO INVALIDA!\n");
    }

    return 0;
}
