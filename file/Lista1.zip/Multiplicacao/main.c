/*
    Aplicativo de Multiplicação v1.0
    Este Aplicativo multiplica dois numeros e mostra o resultado.
    Este Aplicativo é de Domínio Público

    Este Aplicativo foi criado por Cleber Matheus
    email para erros: clebermatheus@outlook.com

    Aplicativo de Multiplicacao v1.0
    Aplicativos Básicos -> Ano: 2013|Tipo: Multiplicação
*/
#include <stdio.h>

int main(){
    // Cabeçalho
    int a,b;
    printf("Aplicativo de Multiplicacao v1.0\n");

    // Pede um numero para o usuario
    printf("Digite um numero: ");
    scanf("%d", &a);

    // Pede outro numero para o usuario
    printf("Digite outro numero: ");
    scanf("%d", &b);

    // Imprime o resultado
    printf("Resultado: %d", a*b);

    return 0;
}
