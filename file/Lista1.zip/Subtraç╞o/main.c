/*
    Aplicativo de Subtração v1.0
    Este Aplicativo subtrai dois números.
    Este Aplicativo é de Domínio Público!
    Alpicativo Criado por Cleber Matheus

    Aplicativo de Subtração v1.0
    Aplicativos Básicos -> Ano: 2013|Tipo: Subtração
*/
#include <stdio.h>

int main()
{
    int a,b;

    // Cabeçalho
    printf("Aplicativo de Subtracao v1.0\n");

    // Pede para o digitar o primeiro numero
    printf("Digite um numero: ");
    scanf("%d", &a);

    // Pede para digitar o segundo numero
    printf("Digite outro numero: ");
    scanf("%d", &b);

    // Agora vem a mágica
    // Imprime o Resultado
    printf("Resultado: %d\n", a - b);

    return 0;
}
