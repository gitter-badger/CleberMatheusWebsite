/*
    Aplicativo de Porcentagem v1.0

    Este Aplicativo calcula a porcentagem e motra o resultado
    Este Aplicativo é de Domínio Público
    Este Aplicativo foi criado por Cleber Matheus
    email para erros: clebermatheus@outlook.com

    Aplicativo de Porcentagem v1.0
    Aplicativos Básicos -> Ano: 2013|Tipo: Porcentagem
*/
#include <stdio.h>
#include <stdlib.h>

int main()
{
    // Cabeçalho
    int a,b,porcento1,porcento2;
    printf("Aplicativo de Porcentagem v1.0\n");

    // Pede um numero
    printf("Digite um numero: ");
    scanf("%d", &a);

    // Pede outro numero
    printf("Digite outro numero: ");
    scanf("%d", &b);

    // Resultado
    porcento1 = (a/b)*100;
    printf("Resultado 1: %d\n", porcento1);
    porcento2 = (a*100)/b;
    printf("Resultado 2: %d\n", porcento2);

    system("PAUSE");
    return 0;
}
