/*
    Aplicativo de Inversão de Inteiros v1.0

    Este Aplicativo inverte valores de positivos para negativos e vice-versa
    Este Aplicativo é de Domínio Público
    Este Aplicativo foi criado por Cleber Matheus
    email para erros: clebermatheus@outlook.com

    Aplicativo de Conversão v1.0
    Aplicativos Básicos -> Ano: 2013|Tipo: Inversor de Números
*/
#include <stdio.h>
#include <stdlib.h>

int main(){
    // Cabeçalho
    int a,inv;
    printf("Aplicativos de Inversao de Numeros v1.0\n");

    // Pede um numero
    printf("Digite um numero: ");
    scanf("%d", &a);

    // Resultado
    inv = a*(-1);
    printf("Resultado usando a*(-1): %d\n", inv);

    system("PAUSE");
    return 0;
}
