/*
    Aplicativo de Divisao v1.0

    Este Aplicativo divide e mostra o resultado e resto da divisao
    Este Aplicativo é de Domínio Público
    Este Aplicativo foi criado por Cleber Matheus
    email para erros: clebermatheus@outlook.com

    Aplicativo de Divisao v1.0
    Aplicativos Básicos -> Ano: 2013|Tipo: Divisao
*/
#include <stdio.h>
#include <stdlib.h>

int main(){
    // Cabeçalho
    int a,b;
    printf("Aplicativo de Divisao\n");

    // Pede um numero
    printf("Digite um numero: ");
    scanf("%d", &a);

    // Pede outro numero
    printf("Digite outro numero: ");
    scanf("%d", &b);

    // Imprime o resultado
    printf("Resultado: %d e o Resto: %d \n", a/b, a%b);

    system("PAUSE");
    return 0;
}
