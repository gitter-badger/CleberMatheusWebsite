/*
    Aplicativo de Soma
    Criado por Cleber Matheus
    Este Aplicativo é de Domínio Público

    Alpicativo de Soma v1.0.0.0
    Aplicativos Básicos -> Ano: 2013|Tipo: Soma
*/
#include <stdio.h>

int main()
{
    int a, b;

    printf("Aplicativo de Somar v1.0.0.0\n");

    printf("Digite um numero: ");
    scanf("%d", &a);

    printf("Digite outro numero: ");
    scanf("%d", &b);

    printf("Resultado: %d\n", a + b);

    return 0;
}
