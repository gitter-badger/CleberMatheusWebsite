/*
    Aplicativo de ParOuImpar v1.0

    Este Aplicativo mostra se um numero é par ou impar
    Este Aplicativo é de Domínio Público
    Este Aplicativo foi criado por Cleber Matheus
    email para erros: clebermatheus@outlook.com

    Aplicativo de ParOuImpar v1.0
    Aplicativos Básicos -> Ano: 2013|Tipo: Par ou Impar
*/
#include <stdio.h>
#include <stdlib.h>

int main(){
    //Cabeçalho
    int a;
    printf("Aplicativo ParOuImpar v1.0\n");

    // Digite um numero
    printf("Digite um numero: ");
    scanf("%d", &a);

    // Resultado
    if(a%2==0){
        printf("0\n");
    }
    else if(a%2==1){
        printf("1
               \n");
    }

    system("PAUSE");
    return 0;
}
