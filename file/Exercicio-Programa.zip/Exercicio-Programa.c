/*
    O Jogo The Lost World v1.0, é um jogo de aventura em modo texto, onde objetivo é chegar no fim indo por vários caminhos, muitos desconhecidos pelo jogador.

    The Lost World 1.0 criado por Cleber Matheus e Flavio de Jesus|Ano: 2013
*/
#include <stdio.h>
#include <stdlib.h>

int main()
{
    // Variaveis
    int opcao,isengard,mordor;

    // Começo do Jogo The Lost World!
    printf("The Lost World!\n");
    printf("Voce agora esta em Lothlorien, nao sabe como chegou aqui e nem para onde ir, mas encontra quatro caminhos diferentes.\n");
    printf("1 - Caminho para o Pantano dos Mortos.\n");
    printf("2 - Caminho para o Rio Anduin\n");
    printf("3 - Caminho para a Floresta de Fangorn\n");
    printf("4 - Caminhdo Desconhecido\n");
    printf("Digite sua escolha: ");
    scanf("%d",&opcao);

    // Todas as opcoes
    if(opcao==1){
        printf("Voce esta no pantano dos mortos, passou por um longo caminho e agora tem que tomar cuidado para nao morrer neste momento.\n");
        printf("1 - Saia do perigo e va para Ithilien, neste caminho.\n");
        printf("2 - Oh! Que caminho maravilhoso e este, ja estou vendo Mordor!\n");
        printf("Digite sua escolha: ");
        scanf("%d", &opcao);
        if(opcao==1){
            printf("Esta quase no fim!, agora escolha uma dos dois caminhos para prosseguir: \n");
            printf("1 - Caminho para Mordor!\n");
            printf("2 - Caminho desconhecido!\n");
            printf("Digite sua escolha: ");
            scanf("%d", &mordor);
        }
        else{
            printf("Oh! Nao era uma armadilha!\nFim de Jogo!\n");
        }
    }
    else{
        // Segunda Opcão
        if(opcao==2){
            printf("Nadando no Rio Anduin, voce encontra duas alternativas.\n");
            printf("1 - Sai do Rio e siga em direcao a Edoras.\n");
            printf("2 - Continuar no Rio Anduin ate Mordor!\n");
            printf("Digite sua escolha: ");
            scanf("%d", &opcao);
            if(opcao==1){
                printf("Atravessando o deserto de Edoras, voce encontra duas alternativas.\n");
                printf("1 - Ir em direcao ao Oeste, chegando ao Abismo de Helm.\n");
                printf("2 - Ir em direcao ao Leste, chegando a Mordor!\n");
                printf("Digite sua escolha: ");
                scanf("%d", &opcao);
                if(opcao==1){
                    printf("Chegando no Abismo de Helm, voce encontra dois caminhos.\n");
                    printf("1 - Caminho para Isengard!\n");
                    printf("2 - Perigoso Caminho para a Senda dos Mortos!\n");
                    printf("Digite sua escolha: ");
                    scanf("%d", &isengard);
                }
            }
            else{
                printf("Socorro!!!Este Rio e muito fundo, nao consigo nadar! Socorrooo!!!!!!!!\n");
            }
        }
        // Terceira Opcao
        if(opcao==3){
            printf("Voce esta atravessando uma floresta cheia de perigos, chamada de Floresta de Fangorn e encontra dois caminhos.\n");
            printf("1 - Caminho para Isengard!\n");
            printf("2 - Caminho para a Senda dos Mortos!\n");
            printf("Digite sua escolha: ");
            scanf("%d", &isengard);
        }
        else{
            if(opcao>=4||opcao<=0){
                printf("Naaaao! Era uma armadilha!\nFim de Jogo!\n");
            }
        }
        switch(isengard){
            case 1:
            printf("Voce esta em Isengard, a Terra dos Morto-Vivos e encontra dois caminhos: \n"
                   "1 - Ir para a Senda dos Mortos\n"
                    "2 - Ir para o Caminhos dos Guerreiros\n"
                    "Digite a sua escolha:");
            scanf("%d",&opcao);
            if(opcao==1){
                printf("Voce esta na Senda dos Mortos, a Terra dos Dinossauros e encontra duas alternativas: \n"
                    "1 - Ir para Minas de Tirith\n"
                    "2 - Ir para a Ilha de Tolfolas\n"
                    "Digite a sua escolha: ");
                scanf("%d", &opcao);
                if(opcao==1){
                    printf("Voce esta nas Minas de Tirith, a Terra das Pedras Preciosas!\n"
                           "1 - Atravessar a Mina dos Diamantes ate Mordor.\n"
                           "2 - Seguir nas Minas de Ouros ate Mordor."
                           "Digite a sua escolha: ");
                    scanf("%d",&mordor);
                }
                else{
                    printf("No meio do caminho para Tolfolas, voce encontra um rio que tenta atravessar e acaba morrendo afogado.\n");
                }
            }
            else{
                printf("No Caminho dos Guerreiros, um dos guerreiros te desafiu para uma luta e te venceu. Fim de Jogo!");
            }
            break;
            default:
                printf("Oh, Nao! Um Tiranossauro! Fim de Jogo!");
        }
    }
    switch(mordor){
        case 1:
            printf("Voce chegou ao Fim do Jogo!\n Parabens voce venceu o Jogo!\n");
            break;
        default:
            printf("No meio do caminho voce e morto por ladroes que tentaram assata-lo!\n");
    }

    return 0;
}
