#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,n=0,aux;

    printf("Digite um numero: ");
    scanf("%d",&b);

    while(n<4){
        printf("Digite um numero: ");
        scanf("%d",&a);
        if(a>b){
            aux=a;
            a=b;
            b=aux;
        }
        n=n+1;
    }

    printf("Resultado: %d\n",b);

    return 0;
}
