#include <stdio.h>
#include <stdlib.h>

int main()
{
    int cont=2;

    while(cont < 1001){
        printf("%d\n",cont);
        cont=cont+2;
    }
    return 0;
}
