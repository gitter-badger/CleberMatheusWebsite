#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,c=1,n=0;

    printf("Digite a base e o expoente: ");
    scanf("%d %d",&a,&b);

    while(n<=b-1){
        c=c*a;
        n=n+1;
    }

    printf("Resultado: %d\n",c);

    return 0;
}
