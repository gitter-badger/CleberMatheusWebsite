#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n=0,a,b=1;

    printf("Digite um numero: ");
    scanf("%d",&a);

    while(n<a){
        b=b*(a+1);
        a=a-1;
        n=n+1;
    }

    printf("Resultado: %d\n",b);

    return 0;
}
