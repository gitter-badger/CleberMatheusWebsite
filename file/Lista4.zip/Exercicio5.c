#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b=0,n=0;

    while(n<5){
        printf("Digite um numero: ");
        scanf("%d",&a);
        b=b+a;
        n=n+1;
    }

    printf("Resultado: %d\n",b);

    return 0;
}
