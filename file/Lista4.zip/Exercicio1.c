#include <stdio.h>
#include <stdlib.h>

int main()
{
    int cont=0;

    while(cont<500){
        printf("Hello world!\n");
        cont = cont + 1;
    }
    return 0;
}
